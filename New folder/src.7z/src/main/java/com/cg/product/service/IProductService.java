package com.cg.product.service;

import java.util.List;

import com.cg.product.beans.Product;


public interface IProductService {

    public boolean addProduct(Product product);
    
    public List<Product> findByProductName(String productName);
    
    public List<Product> findByProductPrice(double productPrice);

    public List<Product> findByProductCategory(String categoryGender,String categoryType);
    List<Product> getProducts();

}