package com.cg.product.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.product.beans.Product;
import com.cg.product.service.IProductService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class ProductController {
    
    @Autowired
    IProductService service;
    
    
    @PostMapping(value="/add")
    public boolean addProduct(@RequestBody Product product)
    {
        boolean res = service.addProduct(product);
        return res;
    }
    
    @GetMapping(value = "/searchByName")
    public List<Product> searchByName(@RequestBody String productName)
    {
        List<Product> productList = service.findByProductName(productName);
        return productList;
    }
  
    @GetMapping(value = "/searchByPrice/{productPrice}")
    public List<Product> searchByPrice(@PathVariable double productPrice)
    {
        List<Product> productList = service.findByProductPrice(productPrice);
        return productList;
    }
    
    @GetMapping(value = "/searchByCategory/{categoryGender}/{categoryType}")
    public List<Product> searchByCategory(@PathVariable final String categoryGender,@PathVariable final String categoryType)
    {
        List<Product> productList = service.findByProductCategory(categoryGender,categoryType);
        return productList;
    }
    @GetMapping(value = "products")
    public List<Product> getProducts()
    {
        List<Product> productList = service.getProducts();
        return productList;
    }
  
//    @PostMapping(value="/addCategory")
//    public boolean addProduct(@RequestBody Category category)
//    {
//        boolean res = categoryService.addCategory(category);
//        return res;
//    }

 


}