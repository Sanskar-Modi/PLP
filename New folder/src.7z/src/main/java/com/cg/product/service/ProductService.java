package com.cg.product.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.product.beans.Product;
import com.cg.product.dao.IProductDao;

@Service
public class ProductService implements IProductService {

	@Autowired
	private IProductDao dao;

	@Override
	public boolean addProduct(Product product) {
//        Category category=new Category();
//        category.setCategoryType("Men");
//        product.setCategory(category);

		if (dao.save(product) != null)
			return true;
		else
			return false;
	}

	@Override
	public List<Product> findByProductName(String productName) {
		return dao.findByProductName(productName);

	}

	@Override
	public List<Product> findByProductPrice(double productPrice) {

		return dao.findByProductPrice(productPrice);
	}

	@Override
	public List<Product> findByProductCategory(String categoryGender,String categoryType) {
		// TODO Auto-generated method stub
		return dao.findByProductCategory(categoryGender,categoryType);
	}

	@Override
	public List<Product> getProducts() {
		// TODO Auto-generated method stub
		List<Product> products =dao.findAll();
		return products;
	}
	
	

}