package com.cg.product.util;



public enum OrderStatus {
	PLACED, PACKED, SHIPPED, DELIVERED;
}