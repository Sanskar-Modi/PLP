package com.cg.product.util;



public enum Status {
	ACTIVE, BLOCKED
}