package com.cg.product.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cg.product.beans.Product;

@Repository
public interface IProductDao extends JpaRepository<Product, Integer> {

	//@Query("from Product where productName =?1")
    List<Product> findByProductName(String productName);
   
    List<Product> findByProductPrice(double productPrice);
   
    @Query("SELECT p FROM Product p WHERE p.category.categoryGender = ?1 and p.category.categoryType = ?2 ")
    List<Product> findByProductCategory(String categoryGender,String categoryType);
    
    
}
